CREATE TABLE IF NOT EXISTS `clickers` (
  `id_Click` int(11) NOT NULL AUTO_INCREMENT,
  `id_Send_Click` int(11) DEFAULT NULL,
  `id_Email_Click` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Click`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=512051 ;

-- --------------------------------------------------------

--
-- Structure de la table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `id_Country` int(11) NOT NULL AUTO_INCREMENT,
  `name_Country` varchar(250) DEFAULT NULL,
  `flag_Country` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_Country`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Structure de la table `creatives`
--

CREATE TABLE IF NOT EXISTS `creatives` (
  `id_Creative` int(11) NOT NULL AUTO_INCREMENT,
  `name_Creative` varchar(250) DEFAULT NULL,
  `id_Offer_Creative` int(11) DEFAULT NULL,
  `isUnsub_Creativ` tinyint(1) NOT NULL,
  `cptClick_Creative` int(11) DEFAULT NULL,
  `cptLead_Creative` int(11) DEFAULT NULL,
  `cptUnsub_Creative` int(11) DEFAULT '0',
  PRIMARY KEY (`id_Creative`),
  KEY `fk_offer` (`id_Offer_Creative`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1268 ;

-- --------------------------------------------------------

--
-- Structure de la table `domain`
--

CREATE TABLE IF NOT EXISTS `domain` (
  `id_Domain` int(11) NOT NULL AUTO_INCREMENT,
  `name_Domain` varchar(250) DEFAULT NULL,
  `saleDate_Domaine` date DEFAULT NULL,
  `expirationDate_Domain` date DEFAULT NULL,
  `id_Domain_Provider_Domain` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Domain`),
  KEY `fk_domain` (`id_Domain_Provider_Domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1542 ;

-- --------------------------------------------------------

--
-- Structure de la table `domainprovider`
--

CREATE TABLE IF NOT EXISTS `domainprovider` (
  `id_DomainProvider` int(11) NOT NULL AUTO_INCREMENT,
  `name_DomainProvider` varchar(250) DEFAULT NULL,
  `note_DomainProvider` varchar(500) DEFAULT NULL,
  `website_DomainProvider` varchar(250) DEFAULT NULL,
  `logo_DomainProvider` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_DomainProvider`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Structure de la table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `id_Email` int(11) NOT NULL AUTO_INCREMENT,
  `email_Email` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName_Email` varchar(250) DEFAULT NULL,
  `lastName_Email` varchar(250) DEFAULT NULL,
  `dob_Email` varchar(250) DEFAULT NULL,
  `state_Email` varchar(250) DEFAULT NULL,
  `id_List_Email` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Email`),
  UNIQUE KEY `email_Email` (`email_Email`),
  KEY `fk_emailList` (`id_List_Email`),
  KEY `email_Email_2` (`email_Email`),
  KEY `email_Email_3` (`email_Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10175643 ;

-- --------------------------------------------------------

--
-- Structure de la table `email_list_warmup`
--

CREATE TABLE IF NOT EXISTS `email_list_warmup` (
  `id_employer` int(11) NOT NULL,
  `id_email` int(11) NOT NULL,
  `password_email` varchar(1500) NOT NULL,
  PRIMARY KEY (`id_employer`,`id_email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `employer`
--

CREATE TABLE IF NOT EXISTS `employer` (
  `id_Employer` int(11) NOT NULL AUTO_INCREMENT,
  `firstName_Employer` varchar(250) DEFAULT NULL,
  `lastName_Employer` varchar(250) DEFAULT NULL,
  `dob_Employer` date DEFAULT NULL,
  `dateIn_Employer` date DEFAULT NULL,
  `dateOut_Employer` date DEFAULT NULL,
  `salaire_Employer` double DEFAULT NULL,
  `id_type_Employer_Employer` int(11) DEFAULT NULL,
  `password_Employer` varchar(250) DEFAULT NULL,
  `id_Isp_Employer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Employer`),
  KEY `fk_type` (`id_type_Employer_Employer`),
  KEY `fk_ispEmployer` (`id_Isp_Employer`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Structure de la table `experience`
--

CREATE TABLE IF NOT EXISTS `experience` (
  `id_Experience` int(11) NOT NULL AUTO_INCREMENT,
  `id_Employer_Experience` int(11) DEFAULT NULL,
  `dateBegin_Experience` date DEFAULT NULL,
  `dateEnd_Experience` date DEFAULT NULL,
  `id_Type_Employer_Experience` int(11) DEFAULT NULL,
  `id_Isp_Experience` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Experience`),
  KEY `fk_ispExper` (`id_Isp_Experience`),
  KEY `fk_employer` (`id_Employer_Experience`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- Structure de la table `froms`
--

CREATE TABLE IF NOT EXISTS `froms` (
  `id_From` int(11) NOT NULL AUTO_INCREMENT,
  `text_From` varchar(250) DEFAULT NULL,
  `id_Offer_From` int(11) DEFAULT NULL,
  `cptOpen_From` int(11) DEFAULT NULL,
  `cptClick_From` int(11) DEFAULT NULL,
  `cptLead_From` int(11) DEFAULT NULL,
  `cptUnsub_From` int(11) DEFAULT '0',
  PRIMARY KEY (`id_From`),
  KEY `fk_offer` (`id_Offer_From`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6887 ;

-- --------------------------------------------------------

--
-- Structure de la table `ip`
--

CREATE TABLE IF NOT EXISTS `ip` (
  `id_IP` int(11) NOT NULL AUTO_INCREMENT,
  `IP_IP` varchar(250) DEFAULT NULL,
  `id_Domain_IP` int(11) DEFAULT NULL,
  `id_Server_IP` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_IP`),
  KEY `fk_server` (`id_Server_IP`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1463 ;

-- --------------------------------------------------------

--
-- Structure de la table `isp`
--

CREATE TABLE IF NOT EXISTS `isp` (
  `id_Isp` int(11) NOT NULL AUTO_INCREMENT,
  `name_isp` varchar(250) DEFAULT NULL,
  `logo_isp` varchar(250) DEFAULT NULL,
  `is_free_isp` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_Isp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------




--
-- Structure de la table `list`
--

CREATE TABLE IF NOT EXISTS `list` (
  `id_List` int(11) NOT NULL AUTO_INCREMENT,
  `name_List` varchar(250) DEFAULT NULL,
  `id_Country_List` int(11) DEFAULT NULL,
  `isActive_List` tinyint(1) DEFAULT NULL,
  `id_Type_List` int(11) DEFAULT NULL,
  `id_ISP_List` int(11) DEFAULT NULL,
  `isOptIN_List` tinyint(1) DEFAULT NULL,
  `fields_List` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_List`),
  KEY `fk_countryList` (`id_Country_List`),
  KEY `fk_typeList` (`id_Type_List`),
  KEY `fk_ISP` (`id_ISP_List`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=878 ;

-- --------------------------------------------------------

--
-- Structure de la table `negative`
--

CREATE TABLE IF NOT EXISTS `negative` (
  `id_negative` int(11) NOT NULL AUTO_INCREMENT,
  `name_negative` varchar(250) DEFAULT NULL,
  `file_negative` varchar(250) DEFAULT NULL,
  `id_mailer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_negative`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=476 ;

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `id_Notification` int(11) NOT NULL AUTO_INCREMENT,
  `text_Notification` text,
  PRIMARY KEY (`id_Notification`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Structure de la table `notification_mailer`
--

CREATE TABLE IF NOT EXISTS `notification_mailer` (
  `id_notification_mailer` int(11) NOT NULL AUTO_INCREMENT,
  `id_notification` int(11) DEFAULT NULL,
  `id_mailer` int(11) DEFAULT NULL,
  `is_Readed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_notification_mailer`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=183 ;

-- --------------------------------------------------------

--
-- Structure de la table `offer`
--

CREATE TABLE IF NOT EXISTS `offer` (
  `id_offer` int(11) NOT NULL AUTO_INCREMENT,
  `name_Offer` varchar(250) DEFAULT NULL,
  `id_Sponsor_Offer` int(11) DEFAULT NULL,
  `id_Country_Offer` varchar(250) DEFAULT NULL,
  `isActive_Offer` tinyint(1) DEFAULT NULL,
  `isSensitive_Offer` tinyint(1) DEFAULT NULL,
  `link_Offer` varchar(250) DEFAULT NULL,
  `unsub_Offer` varchar(250) DEFAULT NULL,
  `suppressionFile_Offer` varchar(250) DEFAULT NULL,
  `notWorkingDays_Offer` varchar(250) DEFAULT NULL,
  `id_Vertical_Offer` int(11) NOT NULL,
  `TypeSuppressionFile_Offer` varchar(250) DEFAULT NULL,
  `sid_Offer` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_offer`),
  KEY `fk_sponsor` (`id_Sponsor_Offer`),
  KEY `fk_vertical` (`id_Vertical_Offer`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=554 ;

-- --------------------------------------------------------

--
-- Structure de la table `openers`
--

CREATE TABLE IF NOT EXISTS `openers` (
  `id_Open` int(11) NOT NULL AUTO_INCREMENT,
  `id_Send_Open` int(11) DEFAULT NULL,
  `id_Email_Open` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Open`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8716329 ;

-- --------------------------------------------------------

--
-- Structure de la table `os`
--

CREATE TABLE IF NOT EXISTS `os` (
  `id_OS` int(11) NOT NULL AUTO_INCREMENT,
  `name_OS` varchar(250) DEFAULT NULL,
  `bit_OS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_OS`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Structure de la table `seedadmin`
--

CREATE TABLE IF NOT EXISTS `seedadmin` (
  `id_seedadmin` int(11) NOT NULL AUTO_INCREMENT,
  `id_isp` int(11) DEFAULT NULL,
  `email` text,
  PRIMARY KEY (`id_seedadmin`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Structure de la table `send`
--

CREATE TABLE IF NOT EXISTS `send` (
  `id_Send` int(11) NOT NULL AUTO_INCREMENT,
  `id_Offer_Send` int(11) NOT NULL,
  `id_ISP_Send` int(11) DEFAULT NULL,
  `id_Employer_Send` int(11) DEFAULT NULL,
  `header_Send` text,
  `body_Send` text,
  `emailTest_Send` text,
  `returnPath_Send` varchar(250) DEFAULT NULL,
  `IPS_Send` text,
  `id_From_Send` int(11) DEFAULT NULL,
  `id_Subject_Send` int(11) DEFAULT NULL,
  `id_Creative_Send` int(11) DEFAULT NULL,
  `startFrom_Send` int(11) NOT NULL DEFAULT '0',
  `cptReceived` int(11) DEFAULT '0',
  `cptDelivered` int(11) DEFAULT '0',
  `cptHardBounce` int(11) DEFAULT '0',
  `cptSoftBounce` int(11) DEFAULT '0',
  `isAR` tinyint(1) DEFAULT '0',
  `ARList` text,
  `is_Sender` tinyint(1) NOT NULL DEFAULT '0',
  `track_Sender` int(11) NOT NULL DEFAULT '0',
  `id_negative` int(11) DEFAULT NULL,
  `extra` text,
  `dateCreation` datetime DEFAULT NULL,
  PRIMARY KEY (`id_Send`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4814 ;

-- --------------------------------------------------------

--
-- Structure de la table `sender`
--

CREATE TABLE IF NOT EXISTS `sender` (
  `id_Email` int(11) DEFAULT NULL,
  `sender` varchar(250) DEFAULT NULL,
  `id_ISP` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sendlist`
--

CREATE TABLE IF NOT EXISTS `sendlist` (
  `id_sendlist` int(11) NOT NULL AUTO_INCREMENT,
  `id_Send` int(11) DEFAULT NULL,
  `id_List` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_sendlist`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38152 ;

-- --------------------------------------------------------

--
-- Structure de la table `sendprocess`
--

CREATE TABLE IF NOT EXISTS `sendprocess` (
  `id_SendProcess` int(11) NOT NULL AUTO_INCREMENT,
  `id_Send` int(11) DEFAULT NULL,
  `host` varchar(250) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_SendProcess`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112337 ;

-- --------------------------------------------------------

--
-- Structure de la table `send_history`
--

CREATE TABLE IF NOT EXISTS `send_history` (
  `id_Send` int(11) DEFAULT NULL,
  `header` text,
  `body` text,
  `id_send_history` int(11) NOT NULL AUTO_INCREMENT,
  `dateUpdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id_send_history`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13910 ;

-- --------------------------------------------------------

--
-- Structure de la table `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `id_Server` int(11) NOT NULL AUTO_INCREMENT,
  `alias_Server` varchar(250) DEFAULT NULL,
  `id_Server_Provider_Server` int(11) DEFAULT NULL,
  `username_Server` varchar(250) DEFAULT NULL,
  `password_Server` varchar(250) DEFAULT NULL,
  `saleDate_Server` date DEFAULT NULL,
  `expirationDate_Server` date DEFAULT NULL,
  `id_OS_Server` int(11) DEFAULT NULL,
  `id_IP_Server` int(11) DEFAULT NULL,
  `isActive_Server` tinyint(1) DEFAULT NULL,
  `isp_Server` varchar(500) DEFAULT NULL,
  `mailerYes_Server` varchar(500) DEFAULT NULL,
  `mailerNo_Server` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_Server`),
  KEY `fk_sprovider` (`id_Server_Provider_Server`),
  KEY `fk_os` (`id_OS_Server`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=283 ;

-- --------------------------------------------------------

--
-- Structure de la table `serverisp`
--

CREATE TABLE IF NOT EXISTS `serverisp` (
  `id_Serverisp` int(11) NOT NULL AUTO_INCREMENT,
  `id_Server` int(11) DEFAULT NULL,
  `id_Isp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Serverisp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2795 ;

-- --------------------------------------------------------

--
-- Structure de la table `servermailer`
--

CREATE TABLE IF NOT EXISTS `servermailer` (
  `id_Servermailer` int(11) NOT NULL AUTO_INCREMENT,
  `id_Server` int(11) DEFAULT NULL,
  `id_Mailer` int(11) DEFAULT NULL,
  `is_Autorised` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_Servermailer`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27308 ;

-- --------------------------------------------------------

--
-- Structure de la table `serverprovider`
--

CREATE TABLE IF NOT EXISTS `serverprovider` (
  `id_ServerProvider` int(11) NOT NULL AUTO_INCREMENT,
  `name_ServerProvider` varchar(250) DEFAULT NULL,
  `note_ServerProvider` varchar(500) DEFAULT NULL,
  `website_ServerProvider` varchar(250) DEFAULT NULL,
  `logo_ServerProvider` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_ServerProvider`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- Structure de la table `sponsor`
--

-- ----------------------------
-- Table structure for `plateform`
-- ----------------------------
DROP TABLE IF EXISTS `plateform`;
CREATE TABLE `plateform` (
  `id_plateform` int(11) NOT NULL AUTO_INCREMENT,
  `name_plateform` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id_plateform`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of plateform
-- ----------------------------
INSERT INTO `plateform` VALUES ('1', 'HitPath');
INSERT INTO `plateform` VALUES ('2', 'Cake');

CREATE TABLE `sponsor` (
  `id_Sponsor` int(11) NOT NULL AUTO_INCREMENT,
  `name_Sponsor` varchar(250) DEFAULT NULL,
  `logo_Sponsor` varchar(250) DEFAULT NULL,
  `isActive_Sponsor` tinyint(1) DEFAULT NULL,
  `login_sponsor` varchar(255) DEFAULT NULL,
  `password_sponsor` varchar(255) DEFAULT NULL,
  `url_login_page_sponsor` varchar(255) DEFAULT NULL,
  `id_plateform_sponsor` int(11) NOT NULL,
  `api_access_key_sponsor` varchar(255) DEFAULT NULL,
  `api_host_url` varchar(3000) DEFAULT NULL,
  `affiliate_id_sponsor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_Sponsor`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sponsor_employee`
--

CREATE TABLE IF NOT EXISTS `sponsor_employee` (
  `id_sponsor` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  PRIMARY KEY (`id_sponsor`,`id_employee`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sponsor_login_history`
--

CREATE TABLE IF NOT EXISTS `sponsor_login_history` (
  `id_sponsor_login_history` int(11) NOT NULL AUTO_INCREMENT,
  `id_sponsor` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `date_login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_login` varchar(1500) NOT NULL,
  PRIMARY KEY (`id_sponsor_login_history`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `id_Subject` int(11) NOT NULL AUTO_INCREMENT,
  `text_Subject` varchar(250) DEFAULT NULL,
  `id_Offer_Subject` int(11) DEFAULT NULL,
  `cptOpen_Subject` int(11) DEFAULT NULL,
  `cptClick_Subject` int(11) DEFAULT NULL,
  `cptLead_Subject` int(11) DEFAULT NULL,
  `cptUnsub_Subject` int(11) DEFAULT '0',
  PRIMARY KEY (`id_Subject`),
  KEY `fk_offer` (`id_Offer_Subject`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22031 ;

-- --------------------------------------------------------

--
-- Structure de la table `ticket`
--

CREATE TABLE IF NOT EXISTS `ticket` (
  `id_ticket` int(11) NOT NULL AUTO_INCREMENT,
  `subject_ticket` varchar(2500) NOT NULL,
  `id_ticket_status` int(11) NOT NULL,
  `id_user_ticket` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_ticket`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

-- --------------------------------------------------------

--
-- Structure de la table `ticket_details`
--

CREATE TABLE IF NOT EXISTS `ticket_details` (
  `id_ticket_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_ticket` int(11) NOT NULL,
  `date_ticket_details` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message_ticket_details` text NOT NULL,
  `is_support_answer` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_ticket_details`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

-- --------------------------------------------------------

--
-- Structure de la table `ticket_status`
--

CREATE TABLE IF NOT EXISTS `ticket_status` (
  `id_ticket_status` int(11) NOT NULL AUTO_INCREMENT,
  `name_ticket_status` varchar(255) NOT NULL,
  PRIMARY KEY (`id_ticket_status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Structure de la table `typelist`
--

CREATE TABLE IF NOT EXISTS `typelist` (
  `id_TypeList` int(11) NOT NULL AUTO_INCREMENT,
  `name_TypeList` varchar(250) DEFAULT NULL,
  `abr_TypeList` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_TypeList`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Structure de la table `type_employer`
--

CREATE TABLE IF NOT EXISTS `type_employer` (
  `id_type_Employer` int(11) NOT NULL AUTO_INCREMENT,
  `name_type_Employer` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_type_Employer`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Structure de la table `unsuboffer`
--

CREATE TABLE IF NOT EXISTS `unsuboffer` (
  `id_Email` int(11) NOT NULL DEFAULT '0',
  `id_Offer` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_Email`,`id_Offer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `unsubscribers`
--

CREATE TABLE IF NOT EXISTS `unsubscribers` (
  `id_Unsub` int(11) NOT NULL AUTO_INCREMENT,
  `id_Send_Unsub` int(11) DEFAULT NULL,
  `id_Email_Unsub` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_Unsub`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2036467 ;

-- --------------------------------------------------------

--
-- Structure de la table `vertical`
--

CREATE TABLE IF NOT EXISTS `vertical` (
  `id_Vertical` int(11) NOT NULL AUTO_INCREMENT,
  `name_Vertical` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_Vertical`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

-- --------------------------------------------------------

--
-- Structure de la table `vl_clickers`
--

CREATE TABLE IF NOT EXISTS `vl_clickers` (
  `id_Email` int(11) NOT NULL DEFAULT '0',
  `id_Isp` int(11) NOT NULL DEFAULT '0',
  `id_Vertical` int(11) NOT NULL DEFAULT '0',
  KEY `fk_i` (`id_Isp`),
  KEY `fk_v` (`id_Vertical`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `vl_openers`
--

CREATE TABLE IF NOT EXISTS `vl_openers` (
  `id_Email` int(11) NOT NULL DEFAULT '0',
  `id_Isp` int(11) NOT NULL DEFAULT '0',
  `id_Vertical` int(11) NOT NULL DEFAULT '0',
  KEY `fk_i` (`id_Isp`),
  KEY `fk_v` (`id_Vertical`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `vmta`
--

CREATE TABLE IF NOT EXISTS `vmta` (
  `id_VMTA` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(250) DEFAULT NULL,
  `domain` varchar(500) DEFAULT NULL,
  `id_Mailer` int(11) DEFAULT NULL,
  `id_Server` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_VMTA`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `creatives`
--
ALTER TABLE `creatives`
  ADD CONSTRAINT `creatives_ibfk_1` FOREIGN KEY (`id_Offer_Creative`) REFERENCES `offer` (`id_offer`) ON DELETE CASCADE;

--
-- Contraintes pour la table `domain`
--
ALTER TABLE `domain`
  ADD CONSTRAINT `domain_ibfk_1` FOREIGN KEY (`id_Domain_Provider_Domain`) REFERENCES `domainprovider` (`id_DomainProvider`) ON DELETE CASCADE;

--
-- Contraintes pour la table `email`
--
ALTER TABLE `email`
  ADD CONSTRAINT `email_ibfk_1` FOREIGN KEY (`id_List_Email`) REFERENCES `list` (`id_List`) ON DELETE CASCADE;

--
-- Contraintes pour la table `employer`
--
ALTER TABLE `employer`
  ADD CONSTRAINT `employer_ibfk_1` FOREIGN KEY (`id_type_Employer_Employer`) REFERENCES `type_employer` (`id_type_Employer`) ON DELETE CASCADE,
  ADD CONSTRAINT `employer_ibfk_2` FOREIGN KEY (`id_Isp_Employer`) REFERENCES `isp` (`id_Isp`) ON DELETE CASCADE;

--
-- Contraintes pour la table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `experience_ibfk_1` FOREIGN KEY (`id_Isp_Experience`) REFERENCES `isp` (`id_Isp`) ON DELETE CASCADE,
  ADD CONSTRAINT `experience_ibfk_2` FOREIGN KEY (`id_Employer_Experience`) REFERENCES `employer` (`id_Employer`) ON DELETE CASCADE;

--
-- Contraintes pour la table `froms`
--
ALTER TABLE `froms`
  ADD CONSTRAINT `froms_ibfk_1` FOREIGN KEY (`id_Offer_From`) REFERENCES `offer` (`id_offer`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ip`
--
ALTER TABLE `ip`
  ADD CONSTRAINT `ip_ibfk_1` FOREIGN KEY (`id_Server_IP`) REFERENCES `server` (`id_Server`) ON DELETE CASCADE;

--
-- Contraintes pour la table `list`
--
ALTER TABLE `list`
  ADD CONSTRAINT `list_ibfk_1` FOREIGN KEY (`id_Country_List`) REFERENCES `country` (`id_Country`) ON DELETE CASCADE,
  ADD CONSTRAINT `list_ibfk_2` FOREIGN KEY (`id_Type_List`) REFERENCES `typelist` (`id_TypeList`) ON DELETE CASCADE,
  ADD CONSTRAINT `list_ibfk_3` FOREIGN KEY (`id_ISP_List`) REFERENCES `isp` (`id_Isp`) ON DELETE CASCADE;

--
-- Contraintes pour la table `offer`
--
ALTER TABLE `offer`
  ADD CONSTRAINT `offer_ibfk_1` FOREIGN KEY (`id_Sponsor_Offer`) REFERENCES `sponsor` (`id_Sponsor`) ON DELETE CASCADE,
  ADD CONSTRAINT `offer_ibfk_2` FOREIGN KEY (`id_Vertical_Offer`) REFERENCES `vertical` (`id_Vertical`) ON DELETE CASCADE;

--
-- Contraintes pour la table `server`
--
ALTER TABLE `server`
  ADD CONSTRAINT `server_ibfk_1` FOREIGN KEY (`id_Server_Provider_Server`) REFERENCES `serverprovider` (`id_ServerProvider`) ON DELETE CASCADE,
  ADD CONSTRAINT `server_ibfk_2` FOREIGN KEY (`id_OS_Server`) REFERENCES `os` (`id_OS`) ON DELETE CASCADE;

--
-- Contraintes pour la table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`id_Offer_Subject`) REFERENCES `offer` (`id_offer`) ON DELETE CASCADE;
