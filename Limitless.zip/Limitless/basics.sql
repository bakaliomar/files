INSERT INTO `country` (`id_Country`, `name_Country`, `flag_Country`) VALUES
(1, 'USA', 'USA.jpg'),
(2, 'UK', 'UK.jpg'),
(3, 'AU', 'Australia.png');


INSERT INTO `os` (`id_OS`, `name_OS`, `bit_OS`) VALUES
(1, 'Centos 6', 64),
(2, 'test', 80);


INSERT INTO `type_employer` (`id_type_Employer`, `name_type_Employer`) VALUES
(1, 'Mailer'),
(2, 'Domains Manager'),
(3, 'Offer Manager');


INSERT INTO `vertical` (`id_Vertical`, `name_Vertical`) VALUES
(1, 'Diet/Weightloss'),
(3, 'Health/Beauty'),
(4, 'Promotional - US'),
(5, 'Surveys'),
(7, 'Mortgage/Refinance'),
(8, 'Miscellaneous'),
(9, 'Credit Report'),
(10, 'Biz Opp/MLM'),
(12, 'Auto Warranty'),
(13, 'Travel'),
(14, 'Cash Advance/PayDay Loan'),
(15, 'Debt/Personal Finance'),
(16, 'Health Insurance'),
(17, 'Education'),
(18, 'Home/Home Improvement'),
(19, 'Psychological'),
(20, 'Diabetes'),
(21, 'Advertorial'),
(22, 'TV/Entertainment'),
(23, 'Auto Financing'),
(25, 'Adult'),
(26, 'Email submit'),
(27, 'Dating'),
(28, 'International'),
(29, 'UK'),
(31, 'Seasonal'),
(32, 'One Time Purchase'),
(34, 'Automotive');



INSERT INTO `isp` (`id_Isp`, `name_isp`, `logo_isp`, `is_free_isp`) VALUES
(1, 'gmail', 'gmail.jpg', 1),
(2, 'aol', 'aol.png', 1),
(3, 'warm up', 'warm up.png', 1),
(5, 'hotmail', 'hotmail.jpg', 1),
(6, 'comcast', 'comcast.jpg', 1),
(7, 'cox', 'cox.png', 1),
(8, 'icloud', 'iCloud.jpg', 1),
(9, 'att', 'att.jpg', 1),
(10, 'yahoo', 'Yahoo.jpg', 1),
(11, 'gmx', 'gmx.png', 1),
(12, 'juno', 'juno.png', 1),
(13, 'netzero', 'netzero.png', 1),
(14, 'verizon', 'virizon.png', 1),
(15, 'bellsouth', 'bellsouth.gif', 1),
(16, 'sbcglobal', 'sbcglobal.gif', 1),
(17, 'btinternet', 'btinternet.gif', 1),
(18, 'virgin', 'virgin.png', 1),
(19, 'teee', 'te.jpg', 0),
(20, 'roadrunner', 'roadrunner.gif', 1),
(21, 'talktalk', 'talktalk.jpg', 0),
(36, 'Publisher','', 0),
(37, 'All','', 0),
(38, 'Samples','', 0);


INSERT INTO `typelist` ( `id_TypeList` , `name_TypeList` , `abr_TypeList` )
VALUES ('1', 'Fresh', 'FRSH'), 
('2', 'Delivered', 'DL'), 
('3', 'Openers', 'OPNS'), 
('4', 'Clickers', 'CLK'), 
('5', 'Unsubcribers', 'UNSUB');

