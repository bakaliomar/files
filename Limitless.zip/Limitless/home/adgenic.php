<?php
$optizmo=0;
$id_offer = $argv[1];


$strUrl = "https://reporting.loadsmooth.com/api.php";
// API KEY
$xmldata = curlpost("https://api.loadsmooth.com/pubapi.php",
array(
"apikey=46a3014e4c87546e6d5499b688bd073e7dea10d043896cc91b9e6e20cb695fe5",
"apifunc=getsuppression",
"campaignid=$id_offer"
)
);



#exit();
$xml = new SimpleXMLElement($xmldata, LIBXML_NOCDATA);
if(!empty($xml))
{
    $nodes = $xml->xpath('data/suppurl');
}
$urlsup=str_replace(",","",$nodes[0][0]);



$cmd="wget --no-check-certificate --quiet -O /home/exactarget/offers/suppression/Adgenic/".$id_offer.".zip ".$urlsup;

exec($cmd,$output,$err);

$cmd1 ="unzip /home/exactarget/offers/suppression/Adgenic/".$id_offer.".zip -d /home/exactarget/offers/suppression/Adgenic/";
exec($cmd1,$output,$err);



$cmd2="ls /home/exactarget/offers/suppression/Adgenic/";
exec($cmd2,$output2,$err);


function curlpost($url, $postdata) {
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_VERBOSE, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, implode("&", $postdata));
$rr = curl_exec($ch);
$headersize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$headers = substr($rr, 0, $headersize);
curl_close($ch);
$result = substr($rr, $headersize);
if (empty($headers)) {
$result = 0;
} else if (!preg_match("/HTTP\/1\.(0|1) 200/i", $headers)) {
$result = 0;
} else {
$result = substr($rr, $headersize);
}
return $result;
}
?>


